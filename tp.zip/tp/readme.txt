﻿Project: Tomb of the Mask


Description: Pacman with a twist; you’re a tomb raider that needs to escape with your riches! Avoid traps and monsters to make it out of the maze alive.


You can run the project by opening the tpUsingKruskals.py file and then running it. app.coins in the appStarted(app) function was changed to 410 coins so that the power-ups can be bought and demoed right off the bat, but for the real game this will be changed to 0. No extra libraries were used.